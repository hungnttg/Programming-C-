﻿using System;

namespace T8
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int[] tau = new int[5] { 6, 9, 1, 5, 3 };
            //in ra truoc khi sap xep
            for (int i = 0; i <= tau.Length - 1; i++)
            {
                Console.Write(tau[i] + ", ");
            }

            //insertionSort(tau);
            BubbleSort(tau);

            //in ra sau khi sap xep
            Console.WriteLine("Sau khi sap xep");
            for (int k = 0; k <= tau.Length-1;k++)
            {
                Console.Write(tau[k] + ", ");
            }

        }
   
        public static void insertionSort(int[] tau)
        {
            //insertion sort
            for (int i = 0; i < tau.Length - 1; i++)
            {
                for (int j = i + 1; j > 0; j--)
                {
                    if (tau[j] < tau[j - 1])
                    {
                        int temp = tau[j - 1];
                        tau[j - 1] = tau[j];
                        tau[j] = temp;
                    }
                }
            }
        }

        public static void BubbleSort(int[] tau)
        { 
            for(int i=0;i<=tau.Length-2;i++)
            {
                for(int j=0;j<=tau.Length-2;j++)
                { 
                    if(tau[j]>tau[j+1])
                    {
                        int temp = tau[j];
                        tau[j] = tau[j+1];
                        tau[j+1] = temp;
                    }
                }
            }
        }




    }
}


