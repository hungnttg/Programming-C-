﻿using System;
using System.IO;

namespace T10
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            ////khai bao mang can luu du lieu
            //string[] arrs = new string[3] { "Nguyen Van A", "Tran Van B", "Vu Van C" };
            //using (StreamWriter sw = new StreamWriter("b.txt"))
            //{
            //    //vong lap
            //    foreach (string s in arrs)
            //    {
            //        sw.WriteLine(s);
            //    }
            //}

            using (StreamReader sr = new StreamReader("b.txt"))
            {
                string line = "";
               while ((line = sr.ReadLine())!=null)
                {
                   
                    Console.WriteLine(line);
                }

                
            }

            Console.ReadKey();

        }
    }
}
