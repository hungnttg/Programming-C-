﻿using System;
namespace T21
{
    public class Diem
    {
        public double Toan;
        public double Ly;
        public double Hoa;

        public void TinhDTB()
        {
            double dtb = (Toan * 3 + Ly * 2 + Hoa) / 6;
            Console.WriteLine("Diem trung binh la:" + dtb);
        }
        public Diem()
        {
        }
        public Diem(double t,double l,double h)
        {
            this.Toan = t;
            this.Ly = l;
            this.Hoa = h;
        }
    }
}
