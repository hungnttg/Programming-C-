﻿using System;

namespace T21
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //string ten = Convert.ToString(Console.ReadLine());
            //double dg = Convert.ToDouble(Console.ReadLine());
            //int sl = Convert.ToInt32(Console.ReadLine());

            ////SanPham sp = new SanPham(ten, dg, sl);
            ////sp.TinhThueNhapKhau();

            //SanPham sp = new SanPham();
            //sp.TenSanPham = ten;
            //sp.DonGia = dg;
            //sp.SoLuong = sl;
            //sp.TinhThueNhapKhau();

            //double bk = Convert.ToDouble(Console.ReadLine());

            //HinhTron ht = new HinhTron();
            //ht.BanKinh = bk;
            //ht.TinhChuVi_DienTich();

            double toan = Convert.ToDouble(Console.ReadLine());
            double ly = Convert.ToDouble(Console.ReadLine());
            double hoa = Convert.ToDouble(Console.ReadLine());

            Diem d = new Diem(toan, ly, hoa);
            d.TinhDTB();

        }
    }
}
