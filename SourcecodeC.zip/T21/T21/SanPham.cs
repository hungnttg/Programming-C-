﻿using System;
namespace T21
{
    public class SanPham
    {
        //thuoc tinh
        public string TenSanPham;
        public double DonGia;
        public int SoLuong;
        //phuong thuc
        public void TinhThueNhapKhau()
        {
            double GiaSanPham = DonGia * SoLuong;
            double ThueNhapKhau = GiaSanPham * 0.1;
            Console.WriteLine("Ten san pham: " + this.TenSanPham);
            Console.WriteLine("Don gia: " + this.DonGia);
            Console.WriteLine("So luong: " + this.SoLuong);
            Console.WriteLine("Thue nhap khau: " + ThueNhapKhau);
        }
        //constructor khong co tham so
        public SanPham()
        {
        }
        //constructor co tham so
        public SanPham(string _tenSP,double _dongia,int _soluong)
        {
            this.TenSanPham = _tenSP;
            this.DonGia = _dongia;
            this.SoLuong = _soluong;

        }
    }
}
