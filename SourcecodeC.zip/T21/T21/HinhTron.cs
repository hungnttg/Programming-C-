﻿using System;
namespace T21
{
    public class HinhTron
    {
        public double BanKinh;
        public void TinhChuVi_DienTich()
        {
            Console.WriteLine("Chu vi hinh tron: " + 2 * 3.14 * BanKinh);
            Console.WriteLine("Dien tich hinh tron: " + 3.14 * BanKinh * BanKinh);
        }
       public HinhTron(double r)
       {
            this.BanKinh = r;

        }
        public HinhTron()
        {
        }
    }
}
