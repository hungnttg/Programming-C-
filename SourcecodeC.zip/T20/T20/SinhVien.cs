﻿using System;
namespace T20
{
    public class SinhVien
    {
        public string HoTen { get; set; }
        public double DiemTrungBinh { get; set; }
        public SinhVien()
        {
        }

        public void DocDuLieu()
        {
            this.HoTen = Convert.ToString(Console.ReadLine());
            this.DiemTrungBinh = Convert.ToDouble(Console.ReadLine());

        }
        public void In()
        {
            Console.WriteLine("Ho ten: " + this.HoTen + 
            "; Diem TB: " + this.DiemTrungBinh);
        }
    }
}
