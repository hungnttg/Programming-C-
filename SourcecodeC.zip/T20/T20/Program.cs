﻿using System;

namespace T20
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Nhap Thong tin sinh vien");
            SinhVien sv = new SinhVien();
            sv.DocDuLieu();
            sv.In();
        }
    }
}
