﻿using System;

namespace Lab8
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int[] mang = new int[10];
            Console.Write("f0=");
            mang[0] = Convert.ToInt32(Console.ReadLine());
            Console.Write("f1");
            mang[1] = Convert.ToInt32(Console.ReadLine());
            for(int i = 2;i<10;i++)
            {
                mang[i] = mang[i - 1] + mang[i - 2];
            }
            //in
            for(int j=0;j<10;j++)
            {
                Console.WriteLine(mang[j]);
            }
        }
    }
}
