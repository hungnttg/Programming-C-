﻿using System;

namespace T3
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            for (int i = 0; true; i++)
            {
                Console.WriteLine("Giai phuong trinh bac 1: ax+b=0");
                Console.Write("a=");
                int a = Convert.ToInt32(Console.ReadLine());
                Console.Write("b=");
                int b = Convert.ToInt32(Console.ReadLine());

                if ((a == 0) && (b == 0)) { Console.WriteLine("PT VSN"); }
                else if ((a == 0) && (b != 0)) { Console.WriteLine("PT VN"); }
                else
                {

                    float x = (float)-b / a;
                    Console.WriteLine("Phuong trinh co nghiem x=" + x);
                }
                Console.WriteLine("==========================");
            }

        }
    }
}
