﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Asm22
{
    public class PatientDal
    {
        public PatientDal()
        {
        }
        public void NextPatient()
        {
            //get current patient
            //create list
            List<Patient> list = new List<Patient>();
            //read file to list
            using (StreamReader sr = new StreamReader("ListPatient.txt"))
            {

                string line = "";
                while ((line = sr.ReadLine()) != null)
                {
                    Patient p = new Patient();
                    p.Name = line;
                    p.Address = sr.ReadLine();
                    p.Telephone = sr.ReadLine();
                    p.Record = Convert.ToInt32(sr.ReadLine());
                    p.DOB = Convert.ToDateTime(sr.ReadLine());
                    p.Gender = Convert.ToInt32(sr.ReadLine());
                    list.Add(p);

                }

            }
            //print list to console
            foreach (Patient p in list)
            {
                Console.WriteLine("Print Patient");
                Console.WriteLine(p.Name);
                Console.WriteLine(p.Address);
                Console.WriteLine(p.Telephone);
                Console.WriteLine(p.Record);
                Console.WriteLine(p.DOB);
                Console.WriteLine(p.Gender);
            }
            //search patient
            Console.WriteLine("Please enter name of patient");
            string EnterName = Convert.ToString(Console.ReadLine());
            int index = list.FindIndex(p => p.Name.Contains(EnterName));
            Patient p1 = new Patient();
            p1 = list[index];
            //print selected patient (p1)
            Console.WriteLine("Current Patient:-------------------------------------- ");
            Console.WriteLine(p1.Name);
            Console.WriteLine(p1.Address);
            Console.WriteLine(p1.Telephone);
            Console.WriteLine(p1.Record);
            Console.WriteLine(p1.DOB);
            Console.WriteLine(p1.Gender);

            //get next patient
            Patient p3 = new Patient();
            if (list.Count <= (index+1))
            {
                Console.WriteLine("The current patient is last parient");
                p3 = list[index];
            }
            else
            {
                p3 = list[index + 1];
            }
            Console.WriteLine("The Next Patient");
            //print next patient
            Console.WriteLine(p3.Name);
            Console.WriteLine(p3.Address);
            Console.WriteLine(p3.Telephone);
            Console.WriteLine(p3.Record);
            Console.WriteLine(p3.DOB);
            Console.WriteLine(p3.Gender);

        }

        public void SearchPatient()
        {
            //create list
            List<Patient> list = new List<Patient>();
            //read file to list
            using (StreamReader sr = new StreamReader("ListPatient.txt"))
            {

                string line = "";
                while ((line = sr.ReadLine()) != null)
                {
                    Patient p = new Patient();
                    p.Name = line;
                    p.Address = sr.ReadLine();
                    p.Telephone = sr.ReadLine();
                    p.Record = Convert.ToInt32(sr.ReadLine());
                    p.DOB = Convert.ToDateTime(sr.ReadLine());
                    p.Gender = Convert.ToInt32(sr.ReadLine());
                    list.Add(p);

                }

            }
            //print list to console
            foreach (Patient p in list)
            {
                Console.WriteLine("Print Patient");
                Console.WriteLine(p.Name);
                Console.WriteLine(p.Address);
                Console.WriteLine(p.Telephone);
                Console.WriteLine(p.Record);
                Console.WriteLine(p.DOB);
                Console.WriteLine(p.Gender);
            }
            //search patient
            Console.WriteLine("Please enter name of patient");
            string EnterName = Convert.ToString(Console.ReadLine());
            int index = list.FindIndex(p => p.Name.Contains(EnterName));
            Patient p1 = new Patient();
            p1 = list[index];
            //print selected patient (p1)
            Console.WriteLine("You search Patient:-------------------------------------- ");
            Console.WriteLine(p1.Name);
            Console.WriteLine(p1.Address);
            Console.WriteLine(p1.Telephone);
            Console.WriteLine(p1.Record);
            Console.WriteLine(p1.DOB);
            Console.WriteLine(p1.Gender);


        }
        public void UpdatePatient()
        {
            List<Patient> list = new List<Patient>();
            //read file to List
            using (StreamReader sr = new StreamReader("ListPatient.txt"))
            {
               
                string line = "";
                while ((line = sr.ReadLine()) != null)
                {
                    Patient p = new Patient();
                    p.Name = line;
                    p.Address = sr.ReadLine();
                    p.Telephone = sr.ReadLine();
                    p.Record = Convert.ToInt32(sr.ReadLine());
                    p.DOB = Convert.ToDateTime(sr.ReadLine());
                    p.Gender = Convert.ToInt32(sr.ReadLine());
                    list.Add(p);

                }

            }

            //print list
            foreach(Patient p in list)
            {
                Console.WriteLine("Print Patient");
                Console.WriteLine(p.Name);
                Console.WriteLine(p.Address);
                Console.WriteLine(p.Telephone);
                Console.WriteLine(p.Record);
                Console.WriteLine(p.DOB);
                Console.WriteLine(p.Gender);
            }
            //select patient
            Console.WriteLine("Please select one patient by enter name of patient");
            string EnterName = Convert.ToString(Console.ReadLine());
            int index = list.FindIndex(p => p.Name.Contains(EnterName));
            Patient p1 = new Patient();
            p1 = list[index];
            //print selected patient (p1)
            Console.WriteLine("You selected Patient:-------------------------------------- ");
            Console.WriteLine(p1.Name);
            Console.WriteLine(p1.Address);
            Console.WriteLine(p1.Telephone);
            Console.WriteLine(p1.Record);
            Console.WriteLine(p1.DOB);
            Console.WriteLine(p1.Gender);
            //update selected patient
            Console.WriteLine("Please Update Patient:-----------");
            Console.WriteLine("Please enter key for Update:");
            Console.WriteLine("1. Update Name");
            Console.WriteLine("2. Update Address");
            Console.WriteLine("3. Update Telephone");
            Console.WriteLine("4. Update Record");
            Console.WriteLine("5. Update DOB");
            Console.WriteLine("6. Update Gender");

            int EnterKey = Convert.ToInt32(Console.ReadLine());
            switch(EnterKey)
            {
                case 1:
                    p1.Name = Convert.ToString(Console.ReadLine());
                    break;
                case 2:
                    p1.Address = Convert.ToString(Console.ReadLine());
                    break;
                case 3:
                    p1.Telephone = Convert.ToString(Console.ReadLine());
                    break;
                case 4:
                    p1.Record = Convert.ToInt32(Console.ReadLine());
                    break;
                case 5:
                    p1.DOB = Convert.ToDateTime(Console.ReadLine());
                    break;
                case 6:
                    p1.Gender = Convert.ToInt32(Console.ReadLine());
                    break;

            }
            //print selected patient after update
            Console.WriteLine("Information Patient after Update========================= ");
            Console.WriteLine(p1.Name);
            Console.WriteLine(p1.Address);
            Console.WriteLine(p1.Telephone);
            Console.WriteLine(p1.Record);
            Console.WriteLine(p1.DOB);
            Console.WriteLine(p1.Gender);

            // update list to file
            list[index] = p1;
            using (StreamWriter sw = new StreamWriter("ListPatient.txt"))
            {
                foreach (Patient p2 in list)
                {

                    sw.WriteLine(p2.Name);
                    sw.WriteLine(p2.Address);
                    sw.WriteLine(p2.Telephone);
                    sw.WriteLine(p1.Record);
                    sw.WriteLine(p2.DOB);
                    sw.WriteLine(p1.Gender);

                }
            }

            //Patient patient = new Patient();
            //patient= list[0];
            //list.FindIndex(a => a.Name.Contains(Convert.ToString(Console.ReadLine())));
        }
        public void AddPatient()
        {
            //create empty list patient
            List<Patient> ls = new List<Patient>();
            for (int i = 0; true; i++)
            {
                //create one patient
                Patient p = new Patient();
                Console.Write("Name: ");
                p.Name = Convert.ToString(Console.ReadLine());
                Console.Write("Address: ");
                p.Address = Convert.ToString(Console.ReadLine());
                Console.Write("Telephone: ");
                p.Telephone = Convert.ToString(Console.ReadLine());
                Console.Write("Record: ");
                p.Record = Convert.ToInt32(Console.ReadLine());
                Console.Write("DOB: ");
                p.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Gender: ");
                p.Gender = Convert.ToInt32(Console.ReadLine());
                //save file
                using (StreamWriter sw =  File.AppendText("ListPatient.txt"))
                {
                    sw.WriteLine(p.Name);
                    sw.WriteLine(p.Address);
                    sw.WriteLine(p.Telephone);
                    sw.WriteLine(p.Record);
                    sw.WriteLine(p.DOB);
                    sw.WriteLine(p.Gender);

                }
                //add patient to list
                ls.Add(p);

                //ESC
                ConsoleKeyInfo cki;
                Console.WriteLine("Press the Escape (Esc) key to quit: \n");
                cki = Console.ReadKey();
                if (cki.Key == ConsoleKey.Escape)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Continue");
                    continue;
                }
            }
        }
    }
}
