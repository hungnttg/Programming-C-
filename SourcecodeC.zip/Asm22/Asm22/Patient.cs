﻿using System;
namespace Asm22
{
    public class Patient
    {
        public string Name;
        public string Address;
        public string Telephone;
        public int Record;
        public DateTime DOB;
        public int Gender;

        public Patient()
        {
        }
        public Patient(string _Name, string _Address, string _Telephone, int _Record, DateTime _DOB, int _Gender)
        {
            this.Name = _Name;
            this.Address = _Address;
            this.Telephone = _Telephone;
            this.Record = _Record;
            this.DOB = _DOB;
            this.Gender = _Gender;

        }
    }
}
