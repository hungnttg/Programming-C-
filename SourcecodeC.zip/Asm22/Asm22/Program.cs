﻿using System;

namespace Asm22
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Patient Managemengt");
            Console.WriteLine("Please select function key: ");
            Console.WriteLine("1. Insert Patient");
            Console.WriteLine("2. Update Patient");
            Console.WriteLine("3. Delete Patient");
            Console.WriteLine("4. Search Patient");
            Console.WriteLine("5. First Patient");
            Console.WriteLine("6. Last Patient");
            Console.WriteLine("7. Next Patient");
            Console.WriteLine("8. Prev Patient");
            //call function
            MenuPatient(Convert.ToInt32(Console.ReadLine()));
            Console.ReadKey();
        }
        //ex1: function menu
        public static void MenuPatient(int selectFunction)
        {
            PatientDal dal = new PatientDal();
            switch (selectFunction)
            {
                case 1:
                    Console.WriteLine("You selected Insert Patient");
                    dal.AddPatient();
                    break;
                case 2:
                    Console.WriteLine("2. Update Patient");
                    dal.UpdatePatient();
                    break;
                case 3:
                    Console.WriteLine("3. Delete Patient");
                    break;
                case 4:
                    Console.WriteLine("4. Search Patient");
                    dal.SearchPatient();
                    break;
                case 5:
                    Console.WriteLine("5. Insert Patient");
                    break;
                case 6:
                    Console.WriteLine("6. Update Patient");
                    break;
                case 7:
                    Console.WriteLine("7. Next Patient");
                    dal.NextPatient();
                    break;
                case 8:
                    Console.WriteLine("8. Update Patient");
                    break;
            }
        }
    }
}
