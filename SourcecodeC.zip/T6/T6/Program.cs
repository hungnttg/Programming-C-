﻿using System;

namespace T6
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            for (int i = 0; true; i++)
            {
                Console.WriteLine("Giai PT ax2+bx+c=0");
                Console.WriteLine("Nhap cac he so:");
                Console.Write("a="); int a = Convert.ToInt32(Console.ReadLine());
                Console.Write("b="); int b = Convert.ToInt32(Console.ReadLine());
                Console.Write("c="); int c = Convert.ToInt32(Console.ReadLine());

                float delta = b * b - 4 * a * c;
                if (delta < 0) { Console.WriteLine("PT VN"); }
                else if (delta == 0)
                {
                    float x = (float)-b / 2 * a;
                    Console.WriteLine("PT co nghiem kep c=" + x);
                }
                else
                {
                    float x1 = (float)(-b + Math.Sqrt(delta)) / 2 * a;
                    float x2 = (float)(-b - Math.Sqrt(delta)) / 2 * a;
                    Console.WriteLine("PT co 2 nghiem x1=" + x1 + " va x2=" + x2);
                }
                Console.WriteLine("==========================");
                Console.ReadKey();
            }
        }
    }
}
