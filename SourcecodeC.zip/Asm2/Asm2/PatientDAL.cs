﻿using System;
namespace Asm2
{
    public static class PatientDAL
    {
       //define AddPatient Method
       public static void AddPatient()
       {
            //tao 1 doi tuong patient
            Patient p = new Patient();
            Console.WriteLine("Thong tin benh nhan:");
            Console.Write("Name: ");
            p.Name = Convert.ToString(Console.ReadLine());
            Console.Write("Address: ");
            p.Address = Convert.ToString(Console.ReadLine());



        }
    }
}
