﻿using System;
namespace Asm2
{
    public class Patient
    {
        //get, set
        public string Name { get; set; }
        public string Address { get; set; }
        public int Tel { get; set; }
        public int Record { get; set; }
        public DateTime DOB { get; set; }
        public bool Gender { get; set; }


        //phuong thuc khoi tao khong co tham so
        public Patient()
        {
        }
        //dinh nghia get, set
         
        
    }
}
