﻿using System;

namespace Asm2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Menu();
        }

        public static void Menu()
        {
            Console.WriteLine("Please select function:");
            Console.WriteLine("1. Insert Patient");
            Console.WriteLine("2. Update Patient");
            int function = Convert.ToInt32(Console.ReadLine());
            switch(function)
            {
                case 1:
                    PatientDAL.AddPatient();

                 break;
                case 2: break;

            }
        }


    }
}
