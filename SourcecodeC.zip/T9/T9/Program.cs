﻿using System;
using System.IO;

namespace T9
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string[] arrs;            
            using (StreamWriter sw = new StreamWriter("a.txt"))
            {
            arrs = new string[2] { "Nguyen VAn A", "Tran Van B" };
                foreach (string s in arrs)
                {
                    sw.WriteLine(s);
                }
            }
        }
    }
}
