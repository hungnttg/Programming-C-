﻿using System;

namespace Assignment2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Please select Function Key:");
            Console.WriteLine("1. Insert Patient");
            Console.WriteLine("2. Edit Patient");
            Console.WriteLine("3. Update Patient");
            MenuPatient(Convert.ToInt32(Console.ReadLine()));
            //them benh nhan
            PatientDal dal = new PatientDal();
            dal.AddPatient();
        }

        public static void MenuPatient(int PhimChucNang)
        {

            switch (PhimChucNang)
            {
                case 1:
                    Console.WriteLine("Ban chon Insert");
                    break;
                case 2:
                    Console.WriteLine("Ban chon Edit");
                    break;
                case 3:
                    Console.WriteLine("Ban chon Update");
                    break;
            }

            Console.WriteLine("Please select Function Key:");
            Console.WriteLine("1. Insert Patient");
            Console.WriteLine("2. Edit Patient");
            Console.WriteLine("3. Update Patient");

        }
    }
}
