﻿using System;
namespace Assignment2
{
    public class Patient
    {
        public string Name;
        public string Address;
        public string Telephone;
        public int Record;
        public DateTime DOB;
        public int Gender;
        public Patient()
        {
        }

        public Patient(string _name,string _address,string _tele,int _record,DateTime _dob,int _gender)
        {
            this.Name = _name;
            this.Address = _address;
            this.Telephone = _tele;
            this.Record = _record;
            this.DOB = _dob;
            this.Gender = _gender;

        }
    }
}
