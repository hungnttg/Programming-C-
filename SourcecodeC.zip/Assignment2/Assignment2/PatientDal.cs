﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
namespace Assignment2
{
    public class PatientDal
    {
        public void AddPatient()
        {
            List<Patient> list = new List<Patient>();
        //nhap lieu
            string name = Convert.ToString(Console.ReadLine());
            string address = Convert.ToString(Console.ReadLine());
            string telephone = Convert.ToString(Console.ReadLine());
            int record = Convert.ToInt32(Console.ReadLine());
            DateTime dOB = Convert.ToDateTime(Console.ReadLine());
            int gender=Convert.ToInt32(Console.ReadLine());
           //gan du lieu
            Patient p = new Patient();
            p.Name = name;
            p.Address = address;
            p.Telephone = telephone;
            p.Record = record;
            p.DOB = dOB;
            p.Gender = gender;
            //luu vao file 
            using (StreamWriter sw = new StreamWriter("patient.txt"))
            {
                sw.WriteLine(p.Name);
                sw.WriteLine(p.Address);
                sw.WriteLine(p.Telephone);
                sw.WriteLine(p.Record);
                sw.WriteLine(p.DOB);
                sw.WriteLine(p.Gender);
            }
            //////
            list.Add(p);
            //in ra man hinh
            Console.WriteLine("Ban vua them benh nhan:");
            Console.WriteLine("Ho ten: "+p.Name);
            Console.WriteLine("Dia chi: " + p.Address);
            Console.WriteLine("SDT: " + p.Telephone);
            Console.WriteLine("Ban ghi: " + p.Record);
            Console.WriteLine("Ngay sinh: " + p.DOB);
            Console.WriteLine("Gioi tinh: " + p.Gender);

        }
        public PatientDal()
        {
        }
    }
}
