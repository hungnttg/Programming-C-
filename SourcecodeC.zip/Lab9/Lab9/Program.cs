﻿using System;

namespace Lab9
{
    class MainClass
    {
        public static void Main(string[] args)
        {
 
            Console.WriteLine("Kiem tra chan le:");
            Console.Write("a=");
            int a = Convert.ToInt32(Console.ReadLine());
     
            if(a%2==0)
            {
                Console.WriteLine(a + " la so chan");
            }
            else
            {
                Console.WriteLine(a + " la so le");
            }
        }
    }
}
