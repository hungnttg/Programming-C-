﻿using System;
namespace T12
{
    public class MayTinh
    {
        public float Rong;
        public float Dai;
        //phuong thuc khoi tao (constructor)
        public MayTinh()
        {
        }

        public float TinhDienTich()
        {
            return Dai * Rong;
        }
    }
}
