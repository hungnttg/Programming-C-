﻿using System;

namespace T12
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            MayTinh mt = new MayTinh();
            mt.Dai = 5;
            mt.Rong = 3;
           float dientich= mt.TinhDienTich();
            Console.WriteLine("Dien tich la:" +dientich);
        }
    }
}
