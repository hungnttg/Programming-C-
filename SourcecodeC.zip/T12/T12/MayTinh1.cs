﻿using System;
namespace T12
{
    public class MayTinh1
    {
        public MayTinh1()
        {
        }
    }
}
