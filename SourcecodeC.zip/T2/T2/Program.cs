﻿using System;

namespace T2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Giai phuong trinh bac 2");
            for (int i = 0; true; i++)
            {
                Console.WriteLine("Nhap vao cac he so: ");
                Console.WriteLine("a=");
                int a, b, c;
                float delta;
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("b=");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("c=");
                c = Convert.ToInt32(Console.ReadLine());
                delta = b * b - 4 * a * c;

                if (delta == 0)
                {
                    float x = -b / 2 * a;
                    Console.WriteLine("Phuong trinh co nghiem kep x=" + -b / 2 * a);
                }
                else if (delta < 0)
                {
                    Console.WriteLine("Phuong trinh vo nghiem");
                }
                else
                {
                    float x1 = (float)(-b + Math.Sqrt(delta)) / 2 * a;
                    float x2 = (float)(-b - Math.Sqrt(delta)) / 2 * a;
                    Console.WriteLine("Phuong trinh co 2 nghiem phan biet x1=" + x1 + " va x2=" + x2);
                }
            }

        }
    }
}
