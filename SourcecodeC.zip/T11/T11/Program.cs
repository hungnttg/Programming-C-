﻿using System;
using System.IO;

namespace T11
{
    class MainClass
    {

        public static void Main(string[] args)
        {
            //ghi vao file
            Read2Array("b.txt");
            //doc tu file
            ReadFile("b.txt");
        }
        public static void ReadFile(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string line = "";
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
        }

        public static void Read2Array(string path)
        {
            string[] ho = new string[6];
            string[] ten = new string[6];
            for(int i=0;i<6;i++)
            {
                Console.WriteLine("Nhap thong tin nguoi thu " + i);
                Console.Write("Nhap ho: ");
                ho[i] = Convert.ToString(Console.ReadLine());
                Console.Write("Nhap ten: ");
                ten[i] = Convert.ToString(Console.ReadLine());
            }
            //ghi vao file
            using (StreamWriter sw = new StreamWriter(path))
            { 
                for(int i=0;i<6;i++)
                {
                    sw.WriteLine(ten[i] + " " + ho[i]);
                }
            }

        }
        public static void ReadAndSaveToFile()
        {

            Console.WriteLine("Hello World!");
            string[] hoten = new string[6];
            //nhap du lieu tu ban phim
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Moi ban nhap ho ten: Nguoi thu " + i);
                hoten[i] = Convert.ToString(Console.ReadLine());
            }
            //ghi vao file
            using (StreamWriter sw = new StreamWriter("a.txt"))
            {
                foreach (string s in hoten)
                {
                    sw.WriteLine(s);
                }

            }
        }
    }
}
