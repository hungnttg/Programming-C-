﻿using System;

namespace T1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            for (int i = 0; true; i++)
            {
                Console.WriteLine("Giai phuong trinh bac 2");
                Console.WriteLine("Nhap vao 3 he so:");
                Console.Write("a=");
                int a, b, c;
                a = Convert.ToInt32(Console.ReadLine());
                //---
                Console.Write("b=");
                b = Convert.ToInt32(Console.ReadLine());
                //--
                Console.Write("c=");
                c = Convert.ToInt32(Console.ReadLine());
                //---
                float delta = b * b - 4 * a * c;
                if (delta == 0)
                {
                    float x = -b / 2 * a;
                    Console.WriteLine("Phuong trinh co nghiem kep x=" + x);
                }
                else if (delta > 0)
                {
                    float x1 = (float)((-b + Math.Sqrt(delta)) / 2 * a);
                    float x2 = (float)(-b - Math.Sqrt(delta)) / 2 * a;
                    Console.WriteLine("Phuong trinh co 2 nghiem x1=" + x1 + " va x2=" + x2);
                }
                else
                {
                    Console.WriteLine("Phuong trinh vo nghiem");
                }

            }
        }
    }
}
